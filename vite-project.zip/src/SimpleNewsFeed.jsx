import "./index.css"


function SimpleNewsFeed() {
  return (
    <div>


    <div className="news-container bg-gradient-to-l  from-[#c7a984] to-orange-100 block sticky z-50 sm:hidden">
        

        
        <ul>
           <li>متن اول</li>
           <li>متن دوم</li>
           <li>متن سوم</li>
           <li>متن چهارم</li>
        </ul>
    </div>


    </div>
  )
}

export default SimpleNewsFeed